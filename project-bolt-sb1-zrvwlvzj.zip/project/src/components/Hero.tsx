import { ArrowDown, Github, Linkedin, Mail, MapPin } from 'lucide-react';
import { profile } from '@/data/portfolio';

export default function Hero() {
  return (
    <section id="home" className="relative min-h-screen flex items-center overflow-hidden pt-24 pb-16">
      {/* Background blobs */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-1/4 -left-20 w-80 h-80 bg-cyan-500/10 rounded-full blur-3xl animate-blob" />
        <div className="absolute top-1/3 right-0 w-96 h-96 bg-blue-600/10 rounded-full blur-3xl animate-blob" style={{ animationDelay: '3s' }} />
        <div className="absolute bottom-0 left-1/3 w-72 h-72 bg-teal-500/5 rounded-full blur-3xl animate-blob" style={{ animationDelay: '6s' }} />
      </div>

      <div className="relative max-w-6xl mx-auto px-6 grid md:grid-cols-2 gap-12 items-center w-full">
        {/* Left — text */}
        <div className="animate-fade-up">
          <span className="inline-flex items-center gap-2 rounded-full glass px-4 py-1.5 text-xs font-medium text-cyan-300 mb-6">
            <span className="w-2 h-2 rounded-full bg-cyan-400 animate-pulse" />
            Available for opportunities
          </span>

          <h1 className="font-display text-4xl sm:text-5xl lg:text-6xl font-bold text-white leading-[1.1] tracking-tight">
            Hi, I'm <span className="text-gradient">Noxolo Mbazini</span>
          </h1>

          <p className="mt-4 text-xl text-slate-300 font-display font-medium">
            {profile.title}
          </p>

          <p className="mt-6 text-slate-400 leading-relaxed max-w-lg">
            {profile.tagline}
          </p>

          <div className="mt-6 flex flex-wrap items-center gap-4 text-sm text-slate-400">
            <span className="inline-flex items-center gap-1.5">
              <MapPin size={15} className="text-cyan-400" />
              {profile.location}
            </span>
          </div>

          <div className="mt-8 flex flex-wrap items-center gap-4">
            <a
              href="#contact"
              className="inline-flex items-center gap-2 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 px-6 py-3 text-sm font-semibold text-white hover:from-cyan-400 hover:to-blue-500 transition-all duration-300 shadow-lg shadow-cyan-500/20"
            >
              <Mail size={17} />
              Get in touch
            </a>
            <a
              href="#projects"
              className="inline-flex items-center gap-2 rounded-xl glass glass-hover px-5 py-3 text-sm font-medium text-slate-200"
            >
              <Github size={17} />
              View projects
            </a>
          </div>

          <div className="mt-8 flex items-center gap-4">
            <a href={profile.github} target="_blank" rel="noopener noreferrer" className="text-slate-500 hover:text-cyan-400 transition-colors" aria-label="GitHub">
              <Github size={20} />
            </a>
            <a href={profile.linkedin} target="_blank" rel="noopener noreferrer" className="text-slate-500 hover:text-cyan-400 transition-colors" aria-label="LinkedIn">
              <Linkedin size={20} />
            </a>
            <a href={`mailto:${profile.email}`} className="text-slate-500 hover:text-cyan-400 transition-colors" aria-label="Email">
              <Mail size={20} />
            </a>
          </div>
        </div>

        {/* Right — visual */}
        <div className="hidden md:flex justify-center animate-fade-up" style={{ animationDelay: '0.2s' }}>
          <div className="relative">
            <div className="w-80 h-80 rounded-3xl glass flex items-center justify-center animate-float">
              <div className="w-72 h-72 rounded-2xl bg-gradient-to-br from-cyan-500/20 via-blue-600/15 to-teal-500/10 flex items-center justify-center border border-white/5">
                <span className="font-display text-8xl font-bold text-gradient">NM</span>
              </div>
            </div>
            {/* Floating chips */}
            <div className="absolute -top-4 -right-4 glass rounded-xl px-4 py-2 text-xs font-medium text-cyan-300 animate-float" style={{ animationDelay: '1s' }}>
              React
            </div>
            <div className="absolute -bottom-4 -left-4 glass rounded-xl px-4 py-2 text-xs font-medium text-sky-300 animate-float" style={{ animationDelay: '2s' }}>
              SQL
            </div>
            <div className="absolute top-1/2 -right-8 glass rounded-xl px-4 py-2 text-xs font-medium text-teal-300 animate-float" style={{ animationDelay: '3s' }}>
              Python
            </div>
          </div>
        </div>
      </div>

      <a
        href="#about"
        className="absolute bottom-6 left-1/2 -translate-x-1/2 text-slate-500 hover:text-cyan-400 transition-colors animate-bounce"
        aria-label="Scroll down"
      >
        <ArrowDown size={22} />
      </a>
    </section>
  );
}
