import { Code2 } from 'lucide-react';
import { skills, softSkills, type Skill } from '@/data/portfolio';

const categories = ['Administration', 'Finance', 'Digital'];

const categoryColors: Record<string, string> = {
  Administration: 'from-cyan-500 to-blue-600',
  Finance: 'from-emerald-500 to-teal-600',
  Digital: 'from-amber-500 to-orange-600',
};

function SkillBar({ skill }: { skill: Skill }) {
  return (
    <div>
      <div className="flex items-center justify-between mb-1.5">
        <span className="text-sm font-medium text-slate-200">{skill.name}</span>
        <span className="text-xs text-slate-500">{skill.level}%</span>
      </div>
      <div className="h-2 rounded-full bg-white/5 overflow-hidden">
        <div
          className={`h-full rounded-full bg-gradient-to-r ${categoryColors[skill.category]} transition-all duration-700`}
          style={{ width: `${skill.level}%` }}
        />
      </div>
    </div>
  );
}

export default function Skills() {
  return (
    <section id="skills" className="relative py-24 px-6 bg-ink-800/40">
      <div className="max-w-6xl mx-auto">
        <div className="flex flex-col items-center text-center">
          <span className="inline-flex items-center gap-2 text-cyan-400 text-sm font-medium font-display uppercase tracking-widest">
            <Code2 size={18} />
            My Expertise
          </span>
          <h2 className="mt-3 font-display text-3xl sm:text-4xl font-bold text-white tracking-tight">
            Professional Skills
          </h2>
          <div className="mt-4 h-1 w-16 rounded-full bg-gradient-to-r from-cyan-500 to-blue-600" />
        </div>

        <div className="grid md:grid-cols-2 gap-8 mt-12">
          {categories.map((cat) => (
            <div key={cat} className="glass rounded-2xl p-6">
              <h3 className="font-display font-semibold text-white mb-5 text-lg">{cat}</h3>
              <div className="space-y-4">
                {skills
                  .filter((s) => s.category === cat)
                  .map((skill) => (
                    <SkillBar key={skill.name} skill={skill} />
                  ))}
              </div>
            </div>
          ))}
        </div>

        {/* Soft skills */}
        <div className="mt-12">
          <h3 className="text-center font-display font-semibold text-white text-lg mb-6">
            Soft Skills
          </h3>
          <div className="flex flex-wrap justify-center gap-3">
            {softSkills.map((skill) => (
              <span
                key={skill}
                className="glass glass-hover rounded-full px-5 py-2 text-sm font-medium text-slate-300"
              >
                {skill}
              </span>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
