import { Mail, Github, Linkedin, MapPin, Send, Download } from 'lucide-react';
import { useState } from 'react';
import { profile } from '@/data/portfolio';

export default function Contact() {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [message, setMessage] = useState('');
  const [sent, setSent] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const subject = encodeURIComponent(`Portfolio contact from ${name}`);
    const body = encodeURIComponent(`${message}\n\nFrom: ${name}\nEmail: ${email}`);
    window.location.href = `mailto:${profile.email}?subject=${subject}&body=${body}`;
    setSent(true);
    setName('');
    setEmail('');
    setMessage('');
    setTimeout(() => setSent(false), 4000);
  };

  const contactItems = [
    { icon: Mail, label: 'Email', value: profile.email, href: `mailto:${profile.email}` },
    { icon: Github, label: 'GitHub', value: 'Profile link coming soon', href: profile.github || undefined },
    { icon: Linkedin, label: 'LinkedIn', value: 'Profile link coming soon', href: profile.linkedin || undefined },
    { icon: MapPin, label: 'Location', value: profile.location, href: undefined },
  ];

  return (
    <section id="contact" className="relative py-24 px-6">
      <div className="max-w-6xl mx-auto">
        <div className="flex flex-col items-center text-center">
          <span className="inline-flex items-center gap-2 text-cyan-400 text-sm font-medium font-display uppercase tracking-widest">
            <Mail size={18} />
            Let's Talk
          </span>
          <h2 className="mt-3 font-display text-3xl sm:text-4xl font-bold text-white tracking-tight">
            Get In Touch
          </h2>
          <div className="mt-4 h-1 w-16 rounded-full bg-gradient-to-r from-cyan-500 to-blue-600" />
          <p className="mt-6 text-slate-400 max-w-lg">
            I'm open to internship and junior developer opportunities. Feel free to reach out via the
            form or any of the channels below.
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-8 mt-12">
          {/* Contact info */}
          <div className="space-y-4">
            {contactItems.map((item) => {
              const Icon = item.icon;
              const content = (
                <div className="glass glass-hover rounded-2xl p-5 flex items-center gap-4">
                  <div className="w-11 h-11 rounded-xl bg-cyan-500/10 border border-cyan-500/20 flex items-center justify-center flex-shrink-0">
                    <Icon size={20} className="text-cyan-400" />
                  </div>
                  <div className="min-w-0">
                    <p className="text-xs text-slate-500 uppercase tracking-wider">{item.label}</p>
                    <p className="text-sm text-slate-200 font-medium truncate">{item.value}</p>
                  </div>
                </div>
              );
              return item.href ? (
                <a
                  key={item.label}
                  href={item.href}
                  target={item.href.startsWith('http') ? '_blank' : undefined}
                  rel="noopener noreferrer"
                  className="block"
                >
                  {content}
                </a>
              ) : (
                <div key={item.label}>{content}</div>
              );
            })}

            <a
              href={profile.cvPath}
              download
              className="inline-flex items-center gap-2 rounded-xl bg-cyan-500/10 border border-cyan-500/30 px-5 py-3 text-sm font-medium text-cyan-300 hover:bg-cyan-500/20 transition-colors mt-2"
            >
              <Download size={16} />
              Download my CV
            </a>
          </div>

          {/* Form */}
          <form onSubmit={handleSubmit} className="glass rounded-2xl p-6 space-y-5">
            <div>
              <label htmlFor="name" className="block text-xs text-slate-400 mb-1.5 font-medium">
                Name
              </label>
              <input
                id="name"
                type="text"
                required
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="w-full rounded-lg bg-white/5 border border-white/10 px-4 py-2.5 text-sm text-white placeholder-slate-500 focus:border-cyan-500/50 focus:outline-none focus:ring-1 focus:ring-cyan-500/30 transition-colors"
                placeholder="Your name"
              />
            </div>
            <div>
              <label htmlFor="email" className="block text-xs text-slate-400 mb-1.5 font-medium">
                Email
              </label>
              <input
                id="email"
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full rounded-lg bg-white/5 border border-white/10 px-4 py-2.5 text-sm text-white placeholder-slate-500 focus:border-cyan-500/50 focus:outline-none focus:ring-1 focus:ring-cyan-500/30 transition-colors"
                placeholder="your@email.com"
              />
            </div>
            <div>
              <label htmlFor="message" className="block text-xs text-slate-400 mb-1.5 font-medium">
                Message
              </label>
              <textarea
                id="message"
                required
                rows={4}
                value={message}
                onChange={(e) => setMessage(e.target.value)}
                className="w-full rounded-lg bg-white/5 border border-white/10 px-4 py-2.5 text-sm text-white placeholder-slate-500 focus:border-cyan-500/50 focus:outline-none focus:ring-1 focus:ring-cyan-500/30 transition-colors resize-none"
                placeholder="Tell me about the opportunity..."
              />
            </div>
            <button
              type="submit"
              className="w-full inline-flex items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 px-6 py-3 text-sm font-semibold text-white hover:from-cyan-400 hover:to-blue-500 transition-all duration-300 shadow-lg shadow-cyan-500/20"
            >
              <Send size={16} />
              {sent ? 'Opening your email...' : 'Send Message'}
            </button>
            {sent && (
              <p className="text-center text-xs text-cyan-400">
                Your email client should now be open. If not, email me directly at {profile.email}.
              </p>
            )}
          </form>
        </div>
      </div>
    </section>
  );
}
