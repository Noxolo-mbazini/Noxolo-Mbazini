import { Globe, GraduationCap, BookOpen, FolderGit2, type LucideIcon } from 'lucide-react';
import { projects } from '@/data/portfolio';

const iconMap: Record<string, LucideIcon> = {
  Globe,
  GraduationCap,
  BookOpen,
};

export default function Projects() {
  return (
    <section id="projects" className="relative py-24 px-6">
      <div className="max-w-6xl mx-auto">
        <div className="flex flex-col items-center text-center">
          <span className="inline-flex items-center gap-2 text-cyan-400 text-sm font-medium font-display uppercase tracking-widest">
            <FolderGit2 size={18} />
            My Work
          </span>
          <h2 className="mt-3 font-display text-3xl sm:text-4xl font-bold text-white tracking-tight">
            Featured Projects
          </h2>
          <div className="mt-4 h-1 w-16 rounded-full bg-gradient-to-r from-cyan-500 to-blue-600" />
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 mt-12">
          {projects.map((project) => {
            const Icon = iconMap[project.icon] ?? Globe;
            return (
              <article
                key={project.title}
                className="glass glass-hover rounded-2xl p-6 flex flex-col group"
              >
                <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-cyan-500/20 to-blue-600/20 border border-cyan-500/20 flex items-center justify-center mb-4">
                  <Icon size={22} className="text-cyan-400" />
                </div>

                <h3 className="font-display font-semibold text-white text-lg group-hover:text-cyan-300 transition-colors">
                  {project.title}
                </h3>
                <p className="mt-3 text-sm text-slate-400 leading-relaxed">
                  {project.description}
                </p>

                <ul className="mt-4 space-y-2">
                  {project.highlights.map((h, i) => (
                    <li key={i} className="flex items-start gap-2 text-xs text-slate-400">
                      <span className="text-cyan-400 mt-0.5">▹</span>
                      {h}
                    </li>
                  ))}
                </ul>

                <div className="mt-auto pt-5 flex flex-wrap gap-2">
                  {project.technologies.map((tech) => (
                    <span
                      key={tech}
                      className="rounded-md bg-white/5 border border-white/5 px-2.5 py-1 text-xs font-medium text-slate-300"
                    >
                      {tech}
                    </span>
                  ))}
                </div>
              </article>
            );
          })}
        </div>
      </div>
    </section>
  );
}
