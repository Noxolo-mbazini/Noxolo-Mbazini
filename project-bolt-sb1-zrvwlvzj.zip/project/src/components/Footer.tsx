import { Github, Linkedin, Mail, ArrowUp } from 'lucide-react';
import { profile } from '@/data/portfolio';

export default function Footer() {
  return (
    <footer className="border-t border-white/5 py-10 px-6">
      <div className="max-w-6xl mx-auto flex flex-col items-center gap-6">
        <a href="#home" className="inline-flex items-center gap-2 text-slate-400 hover:text-cyan-400 transition-colors text-sm">
          <ArrowUp size={16} />
          Back to top
        </a>

        <div className="flex items-center gap-5">
          <a href={profile.github} target="_blank" rel="noopener noreferrer" className="text-slate-500 hover:text-cyan-400 transition-colors" aria-label="GitHub">
            <Github size={20} />
          </a>
          <a href={profile.linkedin} target="_blank" rel="noopener noreferrer" className="text-slate-500 hover:text-cyan-400 transition-colors" aria-label="LinkedIn">
            <Linkedin size={20} />
          </a>
          <a href={`mailto:${profile.email}`} className="text-slate-500 hover:text-cyan-400 transition-colors" aria-label="Email">
            <Mail size={20} />
          </a>
        </div>

        <p className="text-xs text-slate-500 text-center">
          &copy; {new Date().getFullYear()} {profile.name}. Built with React &amp; Tailwind CSS.
        </p>
      </div>
    </footer>
  );
}
