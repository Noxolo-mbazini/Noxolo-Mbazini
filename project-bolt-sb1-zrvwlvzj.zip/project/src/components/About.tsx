import { CheckCircle2, User } from 'lucide-react';
import { about } from '@/data/portfolio';

export default function About() {
  return (
    <section id="about" className="relative py-24 px-6">
      <div className="max-w-6xl mx-auto">
        <SectionHeading icon={<User size={18} />} title="About Me" subtitle="A bit about who I am" />

        <div className="grid lg:grid-cols-3 gap-8 mt-12">
          <div className="lg:col-span-2 space-y-5">
            {about.paragraphs.map((para, i) => (
              <p key={i} className="text-slate-400 leading-relaxed">
                {para}
              </p>
            ))}
          </div>

          <div className="glass rounded-2xl p-6">
            <h3 className="font-display font-semibold text-white mb-4 text-sm uppercase tracking-wider">
              What I Bring
            </h3>
            <ul className="space-y-3">
              {about.highlights.map((item, i) => (
                <li key={i} className="flex items-start gap-3">
                  <CheckCircle2 size={18} className="text-cyan-400 flex-shrink-0 mt-0.5" />
                  <span className="text-sm text-slate-300">{item}</span>
                </li>
              ))}
            </ul>
          </div>
        </div>
      </div>
    </section>
  );
}

function SectionHeading({
  icon,
  title,
  subtitle,
}: {
  icon: React.ReactNode;
  title: string;
  subtitle: string;
}) {
  return (
    <div className="flex flex-col items-center text-center">
      <span className="inline-flex items-center gap-2 text-cyan-400 text-sm font-medium font-display uppercase tracking-widest">
        {icon}
        {subtitle}
      </span>
      <h2 className="mt-3 font-display text-3xl sm:text-4xl font-bold text-white tracking-tight">
        {title}
      </h2>
      <div className="mt-4 h-1 w-16 rounded-full bg-gradient-to-r from-cyan-500 to-blue-600" />
    </div>
  );
}
