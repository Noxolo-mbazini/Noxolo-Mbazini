import { GraduationCap, Award, Briefcase, Calendar } from 'lucide-react';
import { education, certifications, experience } from '@/data/portfolio';

export default function Education() {
  return (
    <section id="education" className="relative py-24 px-6 bg-ink-800/40">
      <div className="max-w-6xl mx-auto">
        <div className="flex flex-col items-center text-center">
          <span className="inline-flex items-center gap-2 text-cyan-400 text-sm font-medium font-display uppercase tracking-widest">
            <GraduationCap size={18} />
            Qualifications
          </span>
          <h2 className="mt-3 font-display text-3xl sm:text-4xl font-bold text-white tracking-tight">
            Education &amp; Certifications
          </h2>
          <div className="mt-4 h-1 w-16 rounded-full bg-gradient-to-r from-cyan-500 to-blue-600" />
        </div>

        <div className="grid lg:grid-cols-2 gap-10 mt-12">
          {/* Education */}
          <div>
            <h3 className="flex items-center gap-2 font-display font-semibold text-white text-lg mb-6">
              <GraduationCap size={20} className="text-cyan-400" />
              Education
            </h3>
            <div className="space-y-4">
              {education.map((item) => (
                <div key={item.qualification} className="glass glass-hover rounded-2xl p-5">
                  <div className="flex items-start justify-between gap-4">
                    <div>
                      <h4 className="font-semibold text-white">{item.qualification}</h4>
                      <p className="text-cyan-300 text-sm mt-1">{item.institution}</p>
                    </div>
                    <span className="inline-flex items-center gap-1 text-xs text-slate-500 whitespace-nowrap">
                      <Calendar size={13} />
                      {item.period}
                    </span>
                  </div>
                  {item.details && (
                    <p className="mt-3 text-sm text-slate-400 leading-relaxed">{item.details}</p>
                  )}
                </div>
              ))}
            </div>
          </div>

          {/* Certifications */}
          <div>
            <h3 className="flex items-center gap-2 font-display font-semibold text-white text-lg mb-6">
              <Award size={20} className="text-cyan-400" />
              Certifications
            </h3>
            <div className="space-y-3">
              {certifications.map((cert) => (
                <div
                  key={cert.name}
                  className="glass glass-hover rounded-2xl p-4 flex items-center justify-between gap-4"
                >
                  <div className="flex items-start gap-3">
                    <div className="w-9 h-9 rounded-lg bg-cyan-500/10 border border-cyan-500/20 flex items-center justify-center flex-shrink-0">
                      <Award size={16} className="text-cyan-400" />
                    </div>
                    <div>
                      <h4 className="text-sm font-medium text-white">{cert.name}</h4>
                      <p className="text-xs text-slate-400 mt-0.5">{cert.issuer}</p>
                    </div>
                  </div>
                  <span className="text-xs text-slate-500 whitespace-nowrap">{cert.period}</span>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Experience */}
        {experience.length > 0 && (
          <div className="mt-14">
            <h3 className="flex items-center gap-2 font-display font-semibold text-white text-lg mb-6">
              <Briefcase size={20} className="text-cyan-400" />
              Work Experience
            </h3>
            <div className="space-y-4">
              {experience.map((exp) => (
                <div key={exp.role} className="glass glass-hover rounded-2xl p-5">
                  <div className="flex flex-wrap items-start justify-between gap-2">
                    <div>
                      <h4 className="font-semibold text-white">{exp.role}</h4>
                      <p className="text-cyan-300 text-sm mt-0.5">{exp.company}</p>
                    </div>
                    <span className="inline-flex items-center gap-1 text-xs text-slate-500">
                      <Calendar size={13} />
                      {exp.period}
                    </span>
                  </div>
                  <p className="mt-3 text-sm text-slate-400 leading-relaxed">{exp.description}</p>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </section>
  );
}
