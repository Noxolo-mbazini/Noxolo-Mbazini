export const profile = {
  name: 'Noxolo Mbazini',
  title: 'Public Management Graduate & Digital Professional',
  tagline:
    'A motivated Public Management graduate with practical workplace experience, strong administrative skills, and a growing passion for creating useful digital experiences.',
  location: 'Eshowe, South Africa',
  email: 'mbazinonoxolo@gmail.com',
  github: '',
  linkedin: '',
  cvPath: '/Mbazini_Noxolo_CV_2026_.pdf',
};

export const about = {
  paragraphs: [
    'I am a Public Management graduate with a National N Diploma from Mthashana TVET College and a practical foundation in public administration, municipal administration, public finance, and computer practice.',
    'My experience includes in-service training with the Department of Public Works and working as a Teacher’s Assistant. These roles strengthened my organisation, communication, record-keeping, and service skills.',
    'I am dependable, eager to learn, and interested in opportunities where I can contribute to efficient administration while continuing to grow my digital and professional skills.',
  ],
  highlights: [
    'National N Diploma graduate in Public Management',
    'Practical experience in public works and classroom support',
    'Strong organisation, communication, and administrative skills',
    'Comfortable with computer practice and learning new tools',
  ],
};

export type Skill = {
  name: string;
  level: number;
  category: string;
};

export const skills: Skill[] = [
  { name: 'Public Administration', level: 85, category: 'Administration' },
  { name: 'Municipal Administration', level: 80, category: 'Administration' },
  { name: 'Records & Document Management', level: 75, category: 'Administration' },
  { name: 'Public Finance', level: 75, category: 'Finance' },
  { name: 'Basic Bookkeeping', level: 65, category: 'Finance' },
  { name: 'Budget Support', level: 65, category: 'Finance' },
  { name: 'Computer Practice', level: 75, category: 'Digital' },
  { name: 'Microsoft Office', level: 70, category: 'Digital' },
  { name: 'Data Entry', level: 75, category: 'Digital' },
];

export const softSkills = [
  'Communication',
  'Teamwork',
  'Problem Solving',
  'Time Management',
  'Adaptability',
  'Critical Thinking',
  'Attention to Detail',
  'Continuous Learning',
];

export type Project = {
  title: string;
  description: string;
  technologies: string[];
  highlights: string[];
  icon: string;
};

export const projects: Project[] = [
  {
    title: 'Personal Portfolio Website',
    description:
      'A modern, responsive personal portfolio built with React and Tailwind CSS to showcase my skills, projects, and professional journey.',
    technologies: ['React', 'TypeScript', 'Tailwind CSS', 'Vite'],
    highlights: [
      'Fully responsive across desktop, tablet, and mobile',
      'Smooth scrolling navigation with animated sections',
      'Clean, modern UI with a dark professional theme',
    ],
    icon: 'Globe',
  },
  {
    title: 'Student Management System',
    description:
      'A desktop application for managing student records, grades, and course enrollments, developed as part of my coursework using C# and a relational database.',
    technologies: ['C#', '.NET', 'SQL Server', 'WinForms'],
    highlights: [
      'CRUD operations for students, courses, and grades',
      'Role-based access for administrators and lecturers',
      'Data validation and user-friendly forms',
    ],
    icon: 'GraduationCap',
  },
  {
    title: 'Library Database System',
    description:
      'A normalized relational database and query set for a library, including book cataloguing, member management, and loan tracking with SQL views and stored procedures.',
    technologies: ['SQL', 'MySQL', 'ERD Design', 'Stored Procedures'],
    highlights: [
      'Full database schema with normalization to 3NF',
      'Stored procedures for issuing and returning books',
      'Reporting views for overdue books and popular titles',
    ],
    icon: 'BookOpen',
  },
];

export type EducationItem = {
  institution: string;
  qualification: string;
  period: string;
  details?: string;
};

export const education: EducationItem[] = [
  {
    institution: 'Mthashana TVET College',
    qualification: 'National N Diploma in Public Management',
    period: 'Awarded 2023',
    details:
      'Completed coursework in municipal administration, public administration, public finance, public law, computer practice, and entrepreneurship and business management.',
  },
];

export type Certification = {
  name: string;
  issuer: string;
  period: string;
};

export const certifications: Certification[] = [
  {
    name: 'National N Diploma in Public Management',
    issuer: 'Mthashana TVET College',
    period: '2023',
  },
  {
    name: 'National Senior Certificate',
    issuer: 'Thongwana JS',
    period: '2024',
  },
  {
    name: 'Code 10 Driver’s Licence',
    issuer: 'South Africa',
    period: '2025',
  },
];

export type ExperienceItem = {
  role: string;
  company: string;
  period: string;
  description: string;
};

export const experience: ExperienceItem[] = [
  {
    role: 'In-Service Trainee',
    company: 'Department of Public Works, Eshowe',
    period: 'Apr 2022 — Sep 2023',
    description:
      'Completed practical in-service training while supporting departmental administration, learning workplace procedures, and contributing to day-to-day public service operations.',
  },
  {
    role: 'Teacher’s Assistant',
    company: 'Justice Nxumalo Technical High School',
    period: 'Nov 2021 — Mar 2022',
    description:
      'Supported teachers and learners with classroom activities, communication, organisation, and day-to-day school administration.',
  },
];

export const navLinks = [
  { label: 'Home', href: '#home' },
  { label: 'About', href: '#about' },
  { label: 'Skills', href: '#skills' },
  { label: 'Projects', href: '#projects' },
  { label: 'Education', href: '#education' },
  { label: 'Contact', href: '#contact' },
];
