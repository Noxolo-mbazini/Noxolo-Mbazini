/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      colors: {
        ink: {
          900: '#0a0f1c',
          800: '#0f1626',
          700: '#151e33',
        },
      },
    },
  },
  plugins: [],
};
